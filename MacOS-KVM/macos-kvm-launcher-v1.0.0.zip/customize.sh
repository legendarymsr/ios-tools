#!/system/bin/sh
# KernelSU/Magisk module install script (runs in booted Android, pm available).
SKIPUNZIP=0
ui_print "- macOS KVM Launcher (OSX-KVM / Sonoma)"
ui_print "- HONEST WARNING: guest is x86_64 on aarch64 = TCG only, VERY slow."
APK="$MODPATH/app/macos-kvm-launcher.apk"
ui_print "- Installing launcher app (com.macoskvm.launcher) ..."
if [ -f "$APK" ]; then
  (pm install -r -g "$APK" || pm install -r "$APK") >/dev/null 2>&1 \
    && ui_print "- App installed. Open it from your launcher." \
    || ui_print "- pm install failed now; it will retry at next boot (service.sh)."
else
  ui_print "- ERROR: bundled APK missing."
fi

# Stage scripts + OSX-KVM assets where the app (and chroot) can reach them.
mkdir -p /data/local/osx-kvm/assets
mkdir -p /data/local/tmp/macos-kvm
cp -f "$MODPATH"/payload/*.sh /data/local/tmp/macos-kvm/ 2>/dev/null
cp -f "$MODPATH"/payload/*.sh /data/local/osx-kvm/ 2>/dev/null
cp -af "$MODPATH"/payload/assets/. /data/local/osx-kvm/assets/ 2>/dev/null
chmod 0755 /data/local/tmp/macos-kvm/* 2>/dev/null
chmod 0755 /data/local/osx-kvm/*.sh /data/local/osx-kvm/assets/fetch-macOS-v2.py 2>/dev/null
ui_print "- Bundled scripts staged at /data/local/tmp/macos-kvm"
ui_print "- OSX-KVM assets staged at /data/local/osx-kvm/assets"
set_perm_recursive "$MODPATH" 0 0 0755 0644
chmod 0644 "$APK" 2>/dev/null
ui_print "- Done. Open 'macOS KVM', grant root, follow the buttons."
