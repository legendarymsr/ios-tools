#!/usr/bin/env bash
# hackios.sh -- run HackiOS (iOS 16.5 user space on Apple's open-source XNU kernel) in QEMU's
# `virt` machine inside this Debian chroot on the phone (launcher steps 2-4).
#
# HackiOS is by OOSEX GANG (@oodze, @netusd, @wannqn, @hxfuxyyXD):
#   https://github.com/oosexgang  ·  https://hackios-web.vercel.app  ·  https://t.me/oosexgangdevs
# hackios-xnu-kernel is APSL 2.0, hackios-xnu-userland is MIT. Nothing of theirs is copied into
# ios-tools: this script clones their repositories at the commits pinned below and runs their own
# scripts. HackiOS is not affiliated with, authorised or endorsed by Apple Inc.; no Apple files are
# shipped -- their ios165/fetch.sh downloads iOS 16.5 from Apple's CDN onto this phone.
#
#   hackios.sh setup    packages, 7-Zip 24.09 (APFS needs 7-Zip 23+), both HackiOS repositories
#   hackios.sh build    download iOS 16.5 (7.4 GB, resumable), build HackiOS's loader and the
#                       images root.apfs + system.apfs (HackiOS's prebuilt kernel and programs)
#   hackios.sh run      boot it: QEMU virt, display on VNC 127.0.0.1:5900, network on (QEMU_NET=1)
#   hackios.sh save     save the running iOS to a snapshot (once it is on the home screen): the next
#                       run resumes it in seconds instead of booting for many minutes (QEMU 8.2+)
#   hackios.sh forget   delete the snapshot, so the next run boots afresh
#   hackios.sh stop     stop that QEMU
#   hackios.sh status   what is installed / built / running
#
# env: HACKIOS_DIR (default /root/hackios), HACKIOS_REF=latest (track main instead of the pins),
#      HACKIOS_SECS (session length, default 7200: the kernel returns to the loader after it),
#      HACKIOS_SMP (vCPUs, default 4), HACKIOS_RAM_GB (guest RAM, default 7: HackiOS's layout
#      puts the 2.5 GB system image high in RAM; the guest RAM is a file mapping, so the phone
#      itself needs about 2.5-3 GB free), HACKIOS_NET=0 (no network; takes effect at the next build),
#      HACKIOS_JOBS=<file> (the job list iOS runs at boot instead of ours; see net_jobs below),
#      HACKIOS_SNAPSHOT=0 (boot afresh even when a snapshot is saved), HACKIOS_TZ=<zone> (iOS's time
#      zone, e.g. Europe/London; the launcher passes Android's persist.sys.timezone),
#      HACKIOS_JB=0 (no jailbreak: leave out HackiOS's Procursus + Sileo prefix; next build),
#      HACKIOS_WALLPAPER=0 (keep iOS's stock default wallpaper instead of the black one; next build).
set -euo pipefail
DIR="${HACKIOS_DIR:-/root/hackios}"
HERE=$(cd "$(dirname "$0")" && pwd)
KERNEL_URL=https://github.com/oosexgang/hackios-xnu-kernel.git
USERLAND_URL=https://github.com/oosexgang/hackios-xnu-userland.git
KERNEL_PIN=8e61187098f2c26c5daee8f9f72b6416aa64b9ab     # 2026-10-22 "Add LICENSE"
USERLAND_PIN=a79ff0772a3454fd1ef127e181e5b3bce6c9ce18   # 2026-10-22
SEVENZIP_VER=2409
declare -A SEVENZIP_SHA=(
  [arm64]=fbe331697c9417bbc06fc92d3f4576dca6a5a1442fad7ae810304446a9153e2c
  [x64]=914c7e20ad5ef8e4d3cf08620ff8894b28fe11b7eb99809d6930870fbe48a281
)
EFI_CODE=/usr/share/AAVMF/AAVMF_CODE.fd
EFI_VARS=/usr/share/AAVMF/AAVMF_VARS.fd

log() { printf '[hackios] %s\n' "$*"; }
die() { printf '[hackios] ERROR: %s\n' "$*" >&2; exit 1; }
credit() {
  log "HackiOS by OOSEX GANG - https://github.com/oosexgang (kernel APSL 2.0, userland MIT)"
}
free_gb() { df -Pk "$1" 2>/dev/null | awk 'NR==2 { print int($4 / 1048576) }'; }
qemu_pids() { pgrep -f "qemu-system-aarch64.*payload\.bin" 2>/dev/null || true; }

install_7zip() {
  if command -v 7z >/dev/null 2>&1 && 7z 2>/dev/null | grep -qE '7-Zip( \(z\))? (2[3-9]|[3-9][0-9])\.'; then
    log "7-Zip: $(7z 2>/dev/null | grep -m1 -oE '7-Zip.*\) [0-9.]+')"; return 0
  fi
  local arch
  case "$(uname -m)" in aarch64|arm64) arch=arm64 ;; x86_64) arch=x64 ;; *) die "no 7-Zip build for $(uname -m)" ;; esac
  local t; t=$(mktemp -d)
  log "installing 7-Zip ${SEVENZIP_VER} ($arch) from github.com/ip7z/7zip (Debian's 7-Zip is too old to read APFS)"
  curl -fsSL --retry 3 -o "$t/7z.tar.xz" \
    "https://github.com/ip7z/7zip/releases/download/${SEVENZIP_VER:0:2}.${SEVENZIP_VER:2}/7z${SEVENZIP_VER}-linux-$arch.tar.xz" \
    || die "7-Zip download failed"
  echo "${SEVENZIP_SHA[$arch]}  $t/7z.tar.xz" | sha256sum -c --quiet - || die "7-Zip download has the wrong checksum"
  mkdir -p /usr/local/lib/7zip && tar -xf "$t/7z.tar.xz" -C /usr/local/lib/7zip
  ln -sf /usr/local/lib/7zip/7zz /usr/local/bin/7z
  rm -rf "$t"
  7z | head -2 | tail -1
}

checkout() { # checkout DIR URL PIN [GIT_DIR]: the pinned commit (or main with HACKIOS_REF=latest)
  local d="$1" url="$2" pin="$3"
  if [ "${HACKIOS_REF:-pinned}" = latest ]; then
    git -C "$d" fetch -q --depth 1 origin main && git -C "$d" checkout -q FETCH_HEAD
  else
    git -C "$d" fetch -q --depth 1 origin "$pin" && git -C "$d" checkout -q "$pin"
  fi
}

do_setup() {
  credit
  local need_gb=14 have; have=$(free_gb "$(dirname "$DIR")")
  [ -n "$have" ] && [ "$have" -lt "$need_gb" ] && log "WARNING: only ${have} GB free; download + images need about ${need_gb} GB"
  log "installing packages (git, python3, gcc, QEMU for aarch64, UEFI firmware)"
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -q || true
  apt-get install -y -q --no-install-recommends git python3 gcc libc6-dev curl ca-certificates xz-utils \
    clang lld qemu-system-arm qemu-efi-aarch64 qemu-utils procps zstd binutils >/dev/null || die "apt-get install failed"
  # snapshots (hackios.sh save) need QEMU 8.2+, which saves the ramfb display; bookworm has 7.2,
  # bookworm-backports has trixie's QEMU 10.0 (no speed difference measured, only the snapshots)
  if ! qemu_ok_for_snapshots && grep -q '^VERSION_CODENAME=bookworm' /etc/os-release 2>/dev/null; then
    log "QEMU $(qemu-system-aarch64 --version | head -1 | awk '{print $4}') cannot save snapshots: installing QEMU 10 from bookworm-backports"
    grep -rqs 'bookworm-backports' /etc/apt/sources.list /etc/apt/sources.list.d/ \
      || echo 'deb http://deb.debian.org/debian bookworm-backports main' > /etc/apt/sources.list.d/bookworm-backports.list
    apt-get update -q >/dev/null || true
    apt-get install -y -q --no-install-recommends -t bookworm-backports qemu-system-arm qemu-utils >/dev/null \
      || log "WARNING: QEMU from bookworm-backports did not install; HackiOS runs, but without snapshots"
  fi
  qemu-system-aarch64 -cpu help 2>/dev/null | grep -qw cortex-a76 \
    || die "this QEMU ($(qemu-system-aarch64 --version | head -1)) has no cortex-a76 CPU; HackiOS needs QEMU 7.1+"
  [ -f "$EFI_CODE" ] && [ -f "$EFI_VARS" ] || die "UEFI firmware missing ($EFI_CODE)"
  install_7zip

  if [ ! -d "$DIR/.git" ]; then
    log "cloning hackios-xnu-kernel into $DIR"
    git init -q "$DIR" && git -C "$DIR" remote add origin "$KERNEL_URL"
  fi
  checkout "$DIR" "$KERNEL_URL" "$KERNEL_PIN"
  # HackiOS's own setup clones hackios-xnu-userland into the same tree (git dir .userland.git)
  ( cd "$DIR" && USERLAND_URL="$USERLAND_URL" bash common/setup.sh ) | grep -E '^setup:|missing' || true
  [ -d "$DIR/.userland.git" ] || die "common/setup.sh did not check out hackios-xnu-userland"
  if [ "${HACKIOS_REF:-pinned}" = latest ]; then
    git --git-dir="$DIR/.userland.git" --work-tree="$DIR" pull -q --ff-only || true
  else
    # a plain checkout keeps setup.sh's skip-worktree marks, so the kernel repository's own
    # README.md, LICENSE and .gitignore in the shared tree are left alone
    git --git-dir="$DIR/.userland.git" --work-tree="$DIR" -c advice.detachedHead=false \
      checkout -q "$USERLAND_PIN" 2>/dev/null \
      || log "WARNING: could not pin hackios-xnu-userland to ${USERLAND_PIN:0:7}; using what setup.sh checked out"
  fi
  log "kernel repo at $(git -C "$DIR" rev-parse --short HEAD), userland repo at $(git --git-dir="$DIR/.userland.git" rev-parse --short HEAD)"
  log "setup done - next: step 3 (download iOS 16.5 + build the images)"
}

# Fixes to HackiOS's checkout (pinned commits), each applied once; report them upstream:
#  - userland/build.sh copies obj/drawable_test, which prebuilt/userland does not have (PREBUILT=1 stops)
#  - userland/build.sh asks timedatectl for the time zone under set -e; without systemd (this chroot)
#    the build stops there without a message
#  - userland/mkjobs.py reuses the loop variable `name` for RWA_PACKED16, so the ~400 on-demand iOS
#    jobs (REST=1: configd, mDNSResponder, trustd, nsurlsessiond, ...) all overwrite one file named
#    RWA_PACKED16 and none of them can start: no DHCP, no DNS, Safari "not connected to the Internet"
#  - (not bugs: two switches for snapshots, default unchanged) qemu/run.sh mounts the ESP read-write
#    and qemu/run-ios.sh always adds virtio-sound; QEMU refuses to save a VM with either, so
#    QEMU_ESP_RW= QEMU_ESP_RO=1 mounts it read-only and QEMU_SOUND=0 leaves the sound device out
#  - (not bugs, ours) userland/build.sh takes the time zone from HACKIOS_TZ when timedatectl has none
#    (the launcher passes Android's), copies obj/timesync into the image when it is there, and
#    qemu/run-ios.sh passes QEMU_NET_EXTRA to the user network (the host's clock for timesync)
#  - xnuloader/loader.c reads back the fw_cfg DMA answer through a plain variable, so -O1 folds the
#    check and the prebuilt loader.efi always gives up on the 1125x2436 ramfb: black screen
#  - (not a bug, ours) QEMU's VNC server drops every row below 2160 (ui/vnc.h VNC_MAX_HEIGHT), which
#    cut iOS's dock off in the launcher's viewer. The loader makes the ramfb PANEL 944x2048 (<=2048,
#    iOS's aspect); iOS still renders 1125x2436 and the kernel scales it onto the panel, exactly as it
#    scales to the real phone's 1080x2400, so the UI is unchanged
fix_checkout() {
  python3 - "$DIR" <<'PYFIX'
import pathlib, sys
d = pathlib.Path(sys.argv[1])
fixes = [
  ("userland/build.sh",
   "\tcp obj/hello_dyn obj/svc_test obj/surf_test obj/drawable_test obj/rwtouch obj/mg_test root/bin/\n",
   "\tfor t in hello_dyn svc_test surf_test drawable_test rwtouch mg_test; do [ -f obj/$t ] && cp obj/$t root/bin/ || true; done\n"),
  ("userland/build.sh",
   "zone=$(timedatectl show -p Timezone --value 2>/dev/null); ",
   "zone=$(timedatectl show -p Timezone --value 2>/dev/null || true); "),
  ("userland/mkjobs.py",
   "        for name in ('RWA_PACKED16',):\n            if os.environ.get(name):\n"
   "                job.setdefault('EnvironmentVariables', {})[name] = os.environ[name]\n        if label in oslog:",
   "        for var in ('RWA_PACKED16',):\n            if os.environ.get(var):\n"
   "                job.setdefault('EnvironmentVariables', {})[var] = os.environ[var]\n        if label in oslog:"),
  ("qemu/run.sh",
   "-drive file=fat:rw:esp,format=raw,if=virtio ",
   "-drive file=fat:${QEMU_ESP_RW-rw:}esp,format=raw,if=virtio${QEMU_ESP_RO:+,readonly=on} "),
  ("qemu/run-ios.sh",
   "if qemu-system-aarch64 -device help 2>/dev/null | grep -q '\"virtio-sound-device\"'; then",
   "if [ \"${QEMU_SOUND:-1}\" != 0 ] && qemu-system-aarch64 -device help 2>/dev/null | grep -q '\"virtio-sound-device\"'; then"),
  ("userland/build.sh",
   "zone=${zone:-UTC}",
   "zone=${zone:-${HACKIOS_TZ:-UTC}}"),
  ("userland/build.sh",
   "\t[ -f obj/cow_test ] && cp obj/cow_test root/bin/\n",
   "\t[ -f obj/cow_test ] && cp obj/cow_test root/bin/\n"
   "\t[ -f obj/timesync ] && cp obj/timesync root/bin/        # ios-tools hackios.sh: the clock after a snapshot\n"),
  ("qemu/run-ios.sh",
   "\tNET=(-netdev user,id=net0 -device virtio-net-device,netdev=net0)\n",
   "\tNET=(-netdev \"user,id=net0${QEMU_NET_EXTRA:+,$QEMU_NET_EXTRA}\" -device virtio-net-device,netdev=net0)\n"),
  ("xnuloader/loader.c",
   "#define PHONE_WIDTH     1125            /* the screen of the iPhone X, whose identity we carry */\n#define PHONE_HEIGHT    2436\n",
   "#define PHONE_WIDTH     1125            /* the screen of the iPhone X, whose identity we carry */\n#define PHONE_HEIGHT    2436\n"
   "/* ios-tools: the ramfb PANEL QEMU presents. iOS renders PHONE_WIDTH x PHONE_HEIGHT and the kernel\n"
   " * scales onto this panel, so the UI is unchanged; <=2048 tall because QEMU VNC here tops out at 2048 (VGA_MAX_HEIGHT). */\n"
   "#define PANEL_WIDTH     944\n#define PANEL_HEIGHT    2048\n"),
  ("xnuloader/loader.c",
   "\tuint64_t fb = 0, bytes = (uint64_t)PHONE_WIDTH * 4 * PHONE_HEIGHT;",
   "\tuint64_t fb = 0, bytes = (uint64_t)PANEL_WIDTH * 4 * PANEL_HEIGHT;"),
  ("xnuloader/loader.c",
   "\tcfg.width = be32(PHONE_WIDTH);\n\tcfg.height = be32(PHONE_HEIGHT);\n\tcfg.stride = be32(PHONE_WIDTH * 4);",
   "\tcfg.width = be32(PANEL_WIDTH);\n\tcfg.height = be32(PANEL_HEIGHT);\n\tcfg.stride = be32(PANEL_WIDTH * 4);"),
  ("xnuloader/loader.c",
   "\tSCREEN.width = PHONE_WIDTH;\n\tSCREEN.height = PHONE_HEIGHT;\n\tSCREEN.stride = PHONE_WIDTH * 4;",
   "\tSCREEN.width = PANEL_WIDTH;\n\tSCREEN.height = PANEL_HEIGHT;\n\tSCREEN.stride = PANEL_WIDTH * 4;"),
  ("xnuloader/loader.c",
   "\t*(volatile uint64_t *)(FW_CFG_BASE + 16) = __builtin_bswap64((uint64_t)(uintptr_t)&dma);\n\tif (dma.control != 0) {\n",
   "\t__asm__ volatile(\"dsb sy\" ::: \"memory\");\n"
   "\t*(volatile uint64_t *)(FW_CFG_BASE + 16) = __builtin_bswap64((uint64_t)(uintptr_t)&dma);\n"
   "\t__asm__ volatile(\"dsb sy\" ::: \"memory\");\n"
   "\tif (*(volatile uint32_t *)&dma.control != 0) {\n"),
]
for f, old, new in fixes:
    p = d / f; s = p.read_text()
    if new in s: continue
    if old not in s:
        print(f"[hackios] note: {f} differs from the pinned commit (fixed by hand or changed upstream): one fix left out"); continue
    p.write_text(s.replace(old, new, 1)); print(f"[hackios] fixed {f}")
PYFIX
}

# What iOS runs at boot (HackiOS's launchd job com.redwood.demo). QEMU's virtio network card (en0)
# has no IOKit object, so configd never sets it up by itself; HackiOS's net_test asks configd's
# IPConfiguration for DHCP on en0 (as their rc.jobs.net does) and QEMU's user network answers.
net_jobs() {
  local f="$DIR/userland/rc.jobs.ios-tools"
  if [ -n "${HACKIOS_JOBS:-}" ]; then echo "$HACKIOS_JOBS"; return; fi
  if [ "${HACKIOS_NET:-1}" = 0 ]; then echo rc.jobs; return; fi
  cat > "$f" <<'JOBS'
# written by ios-tools hackios.sh: DHCP on en0 (QEMU's network), wait for the address, show it
/redwood/bin/net_test dhcp en0 waitaddr en0 180 show
# keep the clock right (it is behind after a snapshot is resumed): the host's clock, else SNTP
/redwood/bin/timesync &
JOBS
  if [ -d "$DIR/jb/root/var/jb" ]; then
    # the jailbreak, as HackiOS's rc.jobs.jb has it: the prefix's preparation once per boot (dpkg's
    # "firmware", Sileo registered with LaunchServices), then fresh package lists for Sileo and apt
    cat >> "$f" <<'JOBS'
/var/jb/bin/sh /var/jb/prep.sh
/redwood/bin/net_test resolve apt.procurs.us
/var/jb/usr/bin/apt-get update
JOBS
  fi
  echo "$f"
}

do_build() {
  credit
  [ -f "$DIR/common/build.sh" ] && [ -d "$DIR/.userland.git" ] || die "not set up yet - run step 2 first"
  command -v 7z >/dev/null || die "7z missing - run step 2 first"
  cd "$DIR"
  if [ ! -f ios165/.done-rootfs ] || [ ! -f ios165/.done-cryptex ] || [ ! -f ios165/.done-cryptex-app ]; then
    log "downloading iOS 16.5 (20F66) from Apple's CDN and extracting it (7.4 GB, resumes if interrupted)"
    bash ios165/fetch.sh
  else
    log "iOS 16.5 files already extracted"
  fi
  fix_checkout
  log "building HackiOS's loader (xnuloader/loader.efi)"
  bash xnuloader/build.sh >/dev/null || die "the loader did not build (clang/lld from step 2?)"
  # the jailbreak, HackiOS's own: tools/mk-jb.sh fetches the Procursus rootless bootstrap, Sileo and
  # ElleKit into jb/, and their build puts it into the system image (/var/jb at run time)
  local jb=off system=
  if [ "${HACKIOS_JB:-1}" != 0 ]; then
    if [ ! -d jb/root/var/jb ]; then
      log "jailbreak: HackiOS's tools/mk-jb.sh (Procursus rootless bootstrap, Sileo, ElleKit)"
      bash tools/mk-jb.sh | tail -2 || die "tools/mk-jb.sh failed (see above)"
    fi
    jb=on
  elif [ -d jb/root ]; then
    log "jailbreak left out (HACKIOS_JB=0)"; rm -rf jb/root
  fi
  # their build remakes system.apfs only when its own inputs change: with the jailbreak added or taken
  # out it has to be remade too (userland/.ios-tools-jb remembers what the image has)
  if [ "$(cat userland/.ios-tools-jb 2>/dev/null || echo off)" != "$jb" ]; then
    system=1; log "the system image is remade ($([ $jb = on ] && echo with || echo without) the jailbreak)"
  fi
  # iOS's default wallpaper (ios-tools): the stock one (identifier 7400) is GPU-composited and comes up
  # a blank white screen without a GPU under QEMU; the "Stripe Black" (7395) is procedural, so the
  # software renderer draws it -- a black background with a thin diagonal stripe. HACKIOS_WALLPAPER=0
  # keeps iOS's stock default. A photo cannot be a wallpaper here: every wallpaper type iOS 16.5 ships
  # (Bokeh, the stripes, LayeredAnimation) is procedural, and a raster "poster" needs the GPU.
  local want_wall=stripe-black; [ "${HACKIOS_WALLPAPER:-1}" = 0 ] && want_wall=stock
  local dwp=ios165/rootfs/Library/Wallpaper/DefaultWallpapers~iphone.plist
  if [ -f "$dwp" ]; then
    [ -f "$dwp.ios-tools-orig" ] || cp "$dwp" "$dwp.ios-tools-orig"
    python3 - "$dwp" "$want_wall" <<'PYWALL'
import plistlib, sys
f, want = sys.argv[1], sys.argv[2]
if want == "stripe-black":
    d = plistlib.load(open(f, "rb"))
    d["default"] = {"wallpaperIdentifier": 7395, "collectionIdentifier": "2939274C-F444-4AA8-806E-6E3FAFBA79B1"}
else:
    d = plistlib.load(open(f + ".ios-tools-orig", "rb"))   # iOS's own default again
plistlib.dump(d, open(f, "wb"))
PYWALL
    if [ "$(cat userland/.ios-tools-wallpaper 2>/dev/null || echo stock)" != "$want_wall" ]; then
      system=1; log "wallpaper: $want_wall (the system image is remade)"
    fi
  fi
  # ours: keeps iOS's clock right after a snapshot is resumed (timesync/timesync.c in ios-tools)
  local ts
  for ts in "$HERE/timesync-arm64" "$HERE/timesync/timesync-arm64"; do
    if [ -f "$ts" ]; then cp -f "$ts" userland/obj/timesync; break; fi
  done
  # iOS's time zone: Android's (the launcher passes it), checked against the zones iOS has
  if [ -n "${HACKIOS_TZ:-}" ] && [ ! -e "ios165/rootfs/usr/share/zoneinfo.default/$HACKIOS_TZ" ]; then
    log "time zone $HACKIOS_TZ is not one iOS has: UTC"; unset HACKIOS_TZ
  fi
  if [ -n "${HACKIOS_TZ:-}" ]; then export HACKIOS_TZ; log "time zone: $HACKIOS_TZ"; fi
  local jobs; jobs=$(net_jobs)
  log "building the images (HackiOS's prebuilt kernel and programs; boot jobs: $(basename "$jobs"))"
  SKIP="kernel loader boot" PREBUILT=1 RC_JOBS="$jobs" SYSTEM=$system bash common/build.sh qemu-virt
  [ -f userland/root.apfs ] && [ -f userland/system.apfs ] && [ -f xnuloader/loader.efi ] \
    || die "the images were not built (see above)"
  echo "$jb" > userland/.ios-tools-jb
  echo "${want_wall:-stock}" > userland/.ios-tools-wallpaper
  log "images: root.apfs $(du -h userland/root.apfs | cut -f1), system.apfs $(du -h userland/system.apfs | cut -f1)"
  log "build done - next: step 4 (boot)"
}

# ---- snapshots ------------------------------------------------------------------------------------
# A snapshot is QEMU's saved VM state (a migration stream in a file): RAM, CPUs and devices. Resuming it
# needs the same QEMU, devices, memory and images, so it is kept with a key of all of those and only
# used when the key still matches. QEMU 8.2+ is needed: older ones do not save the ramfb display.
SNAP_PORT=4445
snap_file() { echo "$DIR/qemu/hackios.snapshot"; }
qemu_ok_for_snapshots() {
  local v; v=$(qemu-system-aarch64 --version 2>/dev/null | head -1 | grep -oE '[0-9]+\.[0-9]+' | head -1)
  [ -n "$v" ] && [ "$(printf '%s\n8.2\n' "$v" | sort -V | head -1)" = 8.2 ]
}
snap_key() {
  ( cd "$DIR" && qemu-system-aarch64 --version | head -1
    echo "smp=${HACKIOS_SMP:-4} ram=${HACKIOS_RAM_GB:-7} net=${HACKIOS_NET:-1} cmdline=${HACKIOS_CMDLINE:-}"
    stat -c '%n %s %Y' userland/root.apfs userland/system.apfs xnuloader/loader.efi prebuilt/mach.development.bcm2837 2>/dev/null
  ) | sha256sum | cut -d' ' -f1
}
# qmp COMMAND-JSON...: send QMP commands to the running QEMU, print each answer; `wait-migration`
# polls query-migrate until it ends and prints its final status
qmp() {
  python3 - "$SNAP_PORT" "$@" <<'PYQMP'
import json, socket, sys, time
port, cmds = int(sys.argv[1]), sys.argv[2:]
deadline = time.time() + 120
while True:
    try:
        s = socket.create_connection(("127.0.0.1", port), timeout=5); break
    except OSError:
        if time.time() > deadline: print("no-qmp"); sys.exit(1)
        time.sleep(1)
f = s.makefile("rw")
def call(cmd):
    f.write(json.dumps(cmd) + "\n"); f.flush()
    while True:
        r = json.loads(f.readline())
        if "return" in r or "error" in r: return r
json.loads(f.readline()); call({"execute": "qmp_capabilities"})
for c in cmds:
    if c == "wait-migration":
        last = None
        while True:
            st = call({"execute": "query-migrate"}).get("return", {})
            status = st.get("status", "none")
            mb = st.get("ram", {}).get("transferred", 0) >> 20
            if status != last or int(time.time()) % 15 == 0:
                print(f"migration: {status}, {mb} MB", flush=True); last = status
            if status in ("completed", "failed", "cancelled"):
                if status == "failed": print("error:", st.get("error-desc", "?"))
                print("final:", status); break
            time.sleep(1)
    else:
        print(json.dumps(call(json.loads(c))))
PYQMP
}

do_run() {
  credit
  cd "$DIR" 2>/dev/null || die "not set up yet - run step 2 first"
  [ -f userland/root.apfs ] && [ -f userland/system.apfs ] || die "no images yet - run step 3 first"
  [ -z "$(qemu_pids)" ] || die "HackiOS is already running (Power off VM stops it)"
  pgrep -f 'qemu-system-aarch64.*-M t8030' >/dev/null && die "another iOS VM (qemu-t8030) is running on the same VNC port - stop it first"
  local avail; avail=$(awk '/^MemAvailable:/ { print int($2 / 1024) }' /proc/meminfo)
  if [ "${avail:-0}" -lt 3000 ]; then
    log "WARNING: only ${avail} MB of memory available; HackiOS wants about 2.5-3 GB. Close other apps if Android kills it."
  fi
  fix_checkout >/dev/null
  local secs="${HACKIOS_SECS:-7200}"
  local net=1; [ "${HACKIOS_NET:-1}" = 0 ] && net=0
  local extra=() snap; snap=$(snap_file)
  if qemu_ok_for_snapshots; then
    # the same devices whether or not this run is saved later: snapshots need them alike
    export QEMU_ESP_RW= QEMU_ESP_RO=1 QEMU_SOUND=0
    if [ "${HACKIOS_SNAPSHOT:-1}" != 0 ] && [ -f "$snap" ] && [ "$(cat "$snap.key" 2>/dev/null)" = "$(snap_key)" ]; then
      log "resuming the saved iOS (snapshot of $(date -r "$snap" '+%Y-%m-%d %H:%M'), $(du -h "$snap" | cut -f1)) instead of booting"
      extra=(-incoming defer)
      # the snapshot was taken with the VM paused, so it loads paused: cont starts it
      ( out=$(qmp "{\"execute\": \"migrate-incoming\", \"arguments\": {\"uri\": \"file:$snap\"}}" wait-migration '{"execute": "cont"}' 2>&1)
        if echo "$out" | grep -q "final: completed"; then
          log "snapshot loaded: iOS is running (its clock is behind by the time it was off)"
        else
          log "the snapshot could not be loaded: $(echo "$out" | grep -E 'error|final' | head -2 | tr '\n' ' ')"
          touch "$DIR/qemu/.snapshot-failed"; qmp '{"execute": "quit"}' >/dev/null 2>&1
        fi ) &
    elif [ -f "$snap" ] && [ "${HACKIOS_SNAPSHOT:-1}" != 0 ]; then
      log "the saved snapshot is from other images or settings: booting afresh (save again once on the home screen)"
    fi
  else
    if [ -f "$snap" ]; then log "snapshots need QEMU 8.2 or newer (this is $(qemu-system-aarch64 --version | head -1 | awk '{print $4}')): booting afresh"; fi
  fi
  if [ ${#extra[@]} = 0 ]; then
    log "booting iOS 16.5 under QEMU virt (TCG, ${HACKIOS_SMP:-4} vCPUs, ${HACKIOS_RAM_GB:-7} GB guest RAM, network=$net, session ${secs} s)"
    log "display: VNC 127.0.0.1:5900 - the lock screen takes several minutes on a phone"
    if qemu_ok_for_snapshots; then log "tip: once iOS is on the home screen, tap \"Save iOS snapshot\" so the next boot takes seconds"; fi
  fi
  log "touch: the pointer with the button held is a finger; swipe up from the bottom edge = home/unlock, from the left edge = back"
  rm -f "$DIR/qemu/.snapshot-failed"
  # the host's clock for timesync in iOS: a connection to 10.0.2.100:37 gets `date +%s.%N`
  export QEMU_NET_EXTRA='guestfwd=tcp:10.0.2.100:37-cmd:date +%s.%N'
  QEMU_FORCE=1 QEMU_NET=$([ "$net" = 1 ] && echo 1 || echo) QEMU_SMP="${HACKIOS_SMP:-4}" \
    QEMU_RAM_GB="${HACKIOS_RAM_GB:-7}" QEMU_EFI="$EFI_CODE" QEMU_VARS="$EFI_VARS" \
    CMDLINE="cpus=${HACKIOS_SMP:-4} ${HACKIOS_CMDLINE:-}" \
    bash qemu/run-ios.sh "$secs" -display vnc=127.0.0.1:0 "${extra[@]}" || true
  wait
  if [ -f "$DIR/qemu/.snapshot-failed" ]; then
    rm -f "$DIR/qemu/.snapshot-failed" "$snap" "$snap.key"
    log "snapshot deleted; booting afresh"
    HACKIOS_SNAPSHOT=0 do_run
  fi
}

do_save() {
  credit
  [ -n "$(qemu_pids)" ] || die "HackiOS is not running - boot it (step 4) and wait for the home screen first"
  qemu_ok_for_snapshots || die "snapshots need QEMU 8.2 or newer; this is $(qemu-system-aarch64 --version | head -1 | awk '{print $4}')"
  ps -o args= -p "$(qemu_pids | head -1)" | grep -q 'fat:esp' \
    || die "this QEMU was started before snapshot support: Power off, boot again (step 4), then save"
  local snap; snap=$(snap_file)
  log "saving iOS to $snap (iOS pauses for this; a few GB)"
  local t0; t0=$(date +%s)
  rm -f "$snap.part"
  local out; out=$(qmp '{"execute": "stop"}' \
    "{\"execute\": \"migrate\", \"arguments\": {\"uri\": \"file:$snap.part\"}}" wait-migration '{"execute": "cont"}' 2>&1)
  if echo "$out" | grep -q "final: completed"; then
    mv -f "$snap.part" "$snap" && snap_key > "$snap.key"
    log "saved in $(( $(date +%s) - t0 )) s, $(du -h "$snap" | cut -f1); iOS keeps running. The next boot (step 4) resumes from here."
  else
    rm -f "$snap.part"
    die "saving failed: $(echo "$out" | grep -E 'error|final|desc' | head -3 | tr '\n' ' ')"
  fi
}

do_forget() {
  rm -f "$(snap_file)" "$(snap_file).key" "$(snap_file).part"
  log "snapshot deleted: the next boot starts afresh"
}

do_stop() {
  if [ -z "$(qemu_pids)" ]; then log "HackiOS is not running"; return 0; fi
  [ -x "$DIR/qemu/stop.sh" ] && bash "$DIR/qemu/stop.sh" || true
  local i; for i in $(seq 1 10); do [ -z "$(qemu_pids)" ] && break; sleep 1; done
  if [ -n "$(qemu_pids)" ]; then kill $(qemu_pids) 2>/dev/null || true; sleep 2; kill -9 $(qemu_pids) 2>/dev/null || true; fi
  log "HackiOS stopped"
}

do_status() {
  credit
  [ -d "$DIR/.git" ] && log "installed: kernel repo $(git -C "$DIR" rev-parse --short HEAD), userland repo $(git --git-dir="$DIR/.userland.git" rev-parse --short HEAD 2>/dev/null || echo '?')" || log "not installed (step 2)"
  [ -f "$DIR/ios165/.done-cryptex-app" ] && log "iOS 16.5 files: extracted" || log "iOS 16.5 files: not yet (step 3)"
  [ -f "$DIR/userland/system.apfs" ] && log "images: built" || log "images: not yet (step 3)"
  [ -f "$(snap_file)" ] && log "snapshot: saved $(date -r "$(snap_file)" '+%Y-%m-%d %H:%M'), $(du -h "$(snap_file)" | cut -f1)" || log "snapshot: none"
  [ -n "$(qemu_pids)" ] && log "running (pid $(qemu_pids | tr '\n' ' '))" || log "not running"
}

case "${1:-status}" in
  setup) do_setup ;;
  build) do_build ;;
  run) do_run ;;
  save) do_save ;;
  forget) do_forget ;;
  stop) do_stop ;;
  status) do_status ;;
  *) die "usage: hackios.sh setup|build|run|save|forget|stop|status" ;;
esac
