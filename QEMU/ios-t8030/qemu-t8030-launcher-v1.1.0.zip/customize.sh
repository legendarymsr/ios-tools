#!/system/bin/sh
SKIPUNZIP=0
ui_print "- iOS t8030 Emulator Launcher v1.1.0"
APK="$MODPATH/app/qemu-t8030-launcher.apk"
ui_print "- Installing launcher app (com.qemut8030.launcher) ..."
if [ -f "$APK" ]; then
  (pm install -r -g "$APK" || pm install -r "$APK") >/dev/null 2>&1 \
    && ui_print "- App installed. Open it from your launcher." \
    || ui_print "- pm install failed now; it will retry at next boot (service.sh)."
else
  ui_print "- ERROR: bundled APK missing."
fi
mkdir -p /data/local/tmp/qemu-t8030
cp -f "$MODPATH"/payload/* /data/local/tmp/qemu-t8030/ 2>/dev/null
chmod 0755 /data/local/tmp/qemu-t8030/* 2>/dev/null
ui_print "- Bundled scripts staged at /data/local/tmp/qemu-t8030"
ui_print "- v1.1.0: tap Download & Configure to pull the IPSW from Apple (~5.5 GB)."
set_perm_recursive "$MODPATH" 0 0 0755 0644
chmod 0644 "$APK" 2>/dev/null
ui_print "- Done."
