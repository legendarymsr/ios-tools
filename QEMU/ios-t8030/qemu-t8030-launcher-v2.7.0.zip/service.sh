#!/system/bin/sh
MODDIR=${0%/*}
if ! pm path com.qemut8030.launcher >/dev/null 2>&1; then
  pm install -r -g "$MODDIR/app/qemu-t8030-launcher.apk" >/dev/null 2>&1 || true
fi
