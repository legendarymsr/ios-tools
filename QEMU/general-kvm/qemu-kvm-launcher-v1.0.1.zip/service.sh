#!/system/bin/sh
# late_start service: retry app install + expose /dev/kvm if the kernel has it.
MODDIR=${0%/*}
if ! pm path com.qemukvm.launcher >/dev/null 2>&1; then
  pm install -r -g "$MODDIR/app/qemu-kvm-launcher.apk" >/dev/null 2>&1 || true
fi
# Samsung stock kernels ship KVM disabled. With a custom CONFIG_KVM=y kernel,
# /dev/kvm exists; make it usable by the app/chroot.
[ -e /dev/kvm ] && chmod 0666 /dev/kvm 2>/dev/null
