#!/system/bin/sh
SKIPUNZIP=0
ui_print "- QEMU KVM Launcher v1.0.2"
APK="$MODPATH/app/qemu-kvm-launcher.apk"
ui_print "- Installing launcher app (com.qemukvm.launcher) ..."
if [ -f "$APK" ]; then
  (pm install -r -g "$APK" || pm install -r "$APK") >/dev/null 2>&1 \
    && ui_print "- App installed. Open it from your launcher." \
    || ui_print "- pm install failed now; it will retry at next boot (service.sh)."
else
  ui_print "- ERROR: bundled APK missing."
fi
mkdir -p /data/local/tmp/qemu-kvm
cp -f "$MODPATH"/payload/* /data/local/tmp/qemu-kvm/ 2>/dev/null
chmod 0755 /data/local/tmp/qemu-kvm/* 2>/dev/null
ui_print "- Bundled scripts staged at /data/local/tmp/qemu-kvm"
ui_print "- v1.0.2: fixed chroot resolv.conf (absolute symlink) + verified staged extract; re-run chroot setup."
set_perm_recursive "$MODPATH" 0 0 0755 0644
chmod 0644 "$APK" 2>/dev/null
ui_print "- Done."
